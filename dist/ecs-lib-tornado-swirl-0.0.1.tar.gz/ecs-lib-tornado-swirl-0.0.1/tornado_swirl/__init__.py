# -*- coding: utf-8 -*-
__version__ = '0.0.1'
__author__ = 'serena'

from tornado_swirl.settings import api_routes
from tornado_swirl.swagger import Application, describe, restapi, schema, add_global_tag

